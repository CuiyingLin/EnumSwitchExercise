import UIKit

//all the different options that can be chosen from
enum bread: CaseIterable {
    case white, wheat
}

enum meat: CaseIterable {
    case turkey, beef, ham
}

enum cheese: CaseIterable {
    case American, cheddar, mozzarella
}

enum vegetable: CaseIterable {
    case lettuce, tomato, both
}

//the order
print("Your sandwich order will be")

//bread
var breadOrder = bread.white
switch breadOrder {
case .white:
    print("white bread and")
case .wheat:
    print("wheat bread and")
}

//meat
var meatOrder = meat.beef
switch meatOrder {
case .turkey:
    print("tasty turkey")
case .beef:
    print("savory roast beef")
case .ham:
    print("delicious slices of ham")
}

//cheese
var cheeseOrder = cheese.cheddar
switch cheeseOrder {
case .American:
    print("topped with American cheese")
case .cheddar:
    print("topped with cheddar cheese")
case .mozzarella:
    print("topped with mozzarella cheese")
}

//vegetable
var vegetableOrder = vegetable.both
switch vegetableOrder {
case .lettuce:
    print("and fresh lettuce.")
case .tomato:
    print("and slices of tomatoes.")
case .both:
    print("and fresh lettuce and slices of tomatoes.")
}
